Ethnocentric
https://www.dafont.com/ethnocentric.font